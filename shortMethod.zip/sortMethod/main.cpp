#include <iostream>
#include <cstdlib>
#include "interface.h"
#include "tester.cpp"
#include <conio.h>

using namespace std;

int main(){

    cout<<"\nProceso de insercion en ejecucion:"<<endl<<endl;
    sortDisplay();
    cout<<"\n\nIsercion realizada !"<<endl<<endl;
    getch();
    return 0;

}
