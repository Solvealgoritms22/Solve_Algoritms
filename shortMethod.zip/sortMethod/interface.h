#ifndef interface_H
#define interface_H

#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <ctime>
#include <algorithm>
#include <cstdlib>

using namespace std;

void sortShell(int* E, int N);
void printArray(int* E, int N, string label);
void insertionSort(int *E, int N);
void mergeSort(int *A, int n);
void merge(int *izq, int nIzq, int *der, int nDer, int *A);
void BurbbleSort(int* E, int n);
int divideQuick(int *E, int a, int b);
void quicksort(int *E, int a, int b);
void SelectionSort(int* E, int n);
void SaveArray(int *E, int n, string name);
void SaveLogArray(int* E, int a, int b, string label);
void swapping(int &a, int &b);
void BurbbleSortOrigen(int* E, int n);
void quicksortBegin(int *E, int n);
void saveTimeSort(int N, string name, clock_t t0);
int* getFromFile(int &N);

#endif
