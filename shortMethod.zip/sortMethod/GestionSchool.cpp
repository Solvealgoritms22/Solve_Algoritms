#include <iostream>
#include <vector>
#include <map>
using namespace std;

//Clase para representar los cursos
class Curso {
public:
    string nombre;
    int creditos;
    vector<string> materias;
    //Constructor
    Curso(string nombre, int creditos, vector<string> materias) {
        this->nombre = nombre;
        this->creditos = creditos;
        this->materias = materias;
    }
};

//Clase para representar los estudiantes
class Estudiante {
public:
    string nombre;
    vector<Curso> cursos;
    //Constructor
    Estudiante(string nombre, vector<Curso> cursos) {
        this->nombre = nombre;
        this->cursos = cursos;
    }
    bool operator<(const Estudiante& estudiante2) const {
        return this->nombre < estudiante2.nombre;
    }
};

//Clase para representar las calificaciones
class Calificacion {
public:
    int nota;
    string materia;
    //Constructor
    Calificacion(int nota, string materia) {
        this->nota = nota;
        this->materia = materia;
    }
};

int main() {
    //Inicializamos los datos
    vector<Curso> cursos = {
        Curso("Programacion", 4, {"Algoritmos", "Estructuras de datos"}),
        Curso("Matematicas", 3, {"Calculo I", "Calculo II"}),
        Curso("Fisica", 5, {"Fisica I", "Fisica II"}),
    };

    vector<Estudiante> estudiantes = {
        Estudiante("Juan", {cursos[0], cursos[1]}),
        Estudiante("Maria", {cursos[1], cursos[2]}),
        Estudiante("Pedro", {cursos[0], cursos[2]})
    };

    map<Estudiante, vector<Calificacion>> calificaciones;
    calificaciones[estudiantes[0]] = {
        Calificacion(10, "Algoritmos"),
        Calificacion(9, "Estructuras de datos")
    };
    calificaciones[estudiantes[1]] = {
        Calificacion(7, "Calculo I"),
        Calificacion(8, "Calculo II")
    };
    calificaciones[estudiantes[2]] = {
        Calificacion(7, "Algoritmos"),
        Calificacion(6, "Fisica I"),
        Calificacion(8, "Fisica II")
    };

    //calculamos el promedio por estudiante
    for (auto const& estudiante : estudiantes) {
        int sumaNotas = 0;
        for (auto const& calificacion : calificaciones[estudiante]) {
            sumaNotas += calificacion.nota;
        }
        float promedio = (float)sumaNotas / (float)calificaciones[estudiante].size();
        cout << "Promedio de " << estudiante.nombre << ": " << promedio << endl;
    }

    return 0;
}
